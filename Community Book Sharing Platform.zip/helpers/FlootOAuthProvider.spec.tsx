// Do not write tests for providers since they mainly interact with external APIs
